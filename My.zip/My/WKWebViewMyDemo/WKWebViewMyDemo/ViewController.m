//
//  ViewController.m
//  WKWebViewMyDemo
//
//  Created by YuXiang on 2017/11/8.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>

@interface ViewController ()<WKScriptMessageHandler,WKNavigationDelegate,WKUIDelegate>
@property (nonatomic, strong) WKWebView *webView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.preferences = [[WKPreferences alloc] init];
    // 默认为0
    config.preferences.minimumFontSize = 10;
    //是否支持JavaScript
    config.preferences.javaScriptEnabled = YES;
    // 不通过用户交互，是否可以打开窗口,默认为NO，表示不能自动通过窗口打开
    config.preferences.javaScriptCanOpenWindowsAutomatically = NO;
   
    /**
    配置Js与Web内容交互
    WKUserContentController是用于给JS注入对象的，注入对象后，JS端就可以使用：
   window.webkit.messageHandlers.<name>.postMessage(<messageBody>)
     
     来调用发送数据给iOS端，比如：
     window.webkit.messageHandlers.AppModel.postMessage({body: '传数据'});
     AppModel就是我们要注入的名称，注入以后，就可以在JS端调用了，传数据统一通过body传，可以是多种类型，只支持NSNumber, NSString, NSDate, NSArray,NSDictionary, and NSNull类型。
     下面我们配置给JS的main frame注入AppModel名称，对于JS端可就是对象了：

     */
    // 通过JS与webview内容交互
    config.userContentController = [[WKUserContentController alloc] init];
    
    /**
     注入JS对象名称AppModel，当JS通过AppModel来调用时，
    我们可以在WKScriptMessageHandler代理中接收到
     */
    [config.userContentController addScriptMessageHandler:self name:@"AppModel"];
    
    
    // 创建WKWebView
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    [self.view addSubview:self.webView];
    
    // 加载H5页面
    NSURL *path = [[NSBundle mainBundle] URLForResource:@"HTML" withExtension:@"html"];
    [self.webView loadRequest:[NSURLRequest requestWithURL:path]];
    // 配置代理
    // 导航代理
    self.webView.navigationDelegate = self;
    // 与webView UI 交互代理
    self.webView.UIDelegate = self;
    // 添加对WKWebView属性的监听
    // WKWebView有好多个支持KVO的属性，这里只是监听loading、title、estimatedProgress属性，分别用于判断是否正在加载、获取页面标题、当前页面载入进度：
    [self.webView addObserver:self forKeyPath:@"loading" options:NSKeyValueObservingOptionNew context:nil];
    [self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:nil];
    [self.webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
}

// 然后我们就可以实现KVO处理方法，在loading完成时，可以注入一些JS到web中。这里只是简单地执行一段web中的JS函数：
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"loading"]) {
        NSLog(@"LINE : %d  loading ",__LINE__);
    }else if ([keyPath isEqualToString:@"title"]) {
        self.title = self.webView.title;
    }else if ([keyPath isEqualToString:@"estimatedProgress"]) {
        NSLog(@"LINE: %d progress: %f", __LINE__,self.webView.estimatedProgress);
//        self.progressView.progress = self.webView.estimatedProgress;
    }
    
    //加载完成
    if (!self.webView.loading) {
        // 手动调用JS代码
        // 每次页面完成都弹出来，大家可以在测试时再打开
        NSString *js = @"callJsAlert()";
        [self.webView evaluateJavaScript:js completionHandler:^(id _Nullable response, NSError * _Nullable error) {
    
            NSLog(@"LINE: %d response: %@ error: %@",__LINE__,response, error);
        }];
        
        [UIView animateWithDuration:0.5 animations:^{
//            self.progressView.alpha = 0;
        }];
        
    }
    
}

/**------------------------------------------------*/
// 当JS通过AppModel发送数据到iOS端时，会在代理中收到：
#pragma mark - WKScriptMessageHandler
// 所有JS调用iOS的部分，都只可以在此处使用哦。当然我们也可以注入多个名称（JS对象），用于区分功能。
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
    if ([message.name isEqualToString:@"AppModel"]) {
        // 打印所传过来的参数，只支持NSNumber, NSString, NSDate, NSArray,
        // NSDictionary, and NSNull类型
        NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
        NSLog(@"LINE : %d -- %@",__LINE__,message.body);
    }
}

/**------------------------------------------------*/
// 如果需要处理web导航操作，比如链接跳转、接收响应、在导航开始、成功、失败等时要做些处理，就可以通过实现相关的代理方法：
#pragma mark - WKNavigationDelegate
// 请求开始前，会先调用此代理方法
// 判断能不能跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
    
    NSString *hostName = navigationAction.request.URL.host.lowercaseString;
    NSURL *url = navigationAction.request.URL;
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated && [hostName containsString:@"www.baidu.com"]) {
     // 对于跨域，需要手动跳转
        UIApplication *application = [UIApplication sharedApplication];
        if (@available(iOS 10.0, *)) {
            [application openURL:url options:@{} completionHandler:^(BOOL success) {
                NSLog(@"Open %d",success);
            }];
        } else {
            BOOL success = [application openURL:url];
            NSLog(@"Open %d",success);
        }
        // 不允许web内跳转
        decisionHandler(WKNavigationActionPolicyCancel);
    }else {
//        self.progressView.alpha = 1.0;
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

// 在响应完成时，会回调此方法
// 如果设置为不允许响应，web内容就不会传过来
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    decisionHandler(WKNavigationResponsePolicyAllow);
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 开始导航跳转时会回调
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 接收到重定向时会回调
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 导航失败时会回调
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 页面内容到达main frame时回调
- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation {
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 导航完成时，会回调（也就是页面载入完成了）
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 导航失败时会回调
- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
}

// 对于HTTPS的都会触发此代理，如果不要求验证，传默认就行
// 如果需要证书验证，与使用AFN进行HTTPS证书验证是一样的, 参考 ： http://www.jianshu.com/p/ff0c317fd1c7
- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *__nullable credential))completionHandler {
    
     NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
    /**
     if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
     
     NSURLCredential *card = [[NSURLCredential alloc]initWithTrust:challenge.protectionSpace.serverTrust];
     
     completionHandler(NSURLSessionAuthChallengeUseCredential,card);
     }
     */
}
// 9.0才能使用，web内容处理中断时会触发
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    NSLog(@"LINE : %d -- %s",__LINE__, __FUNCTION__);
}

/**------------------------------------------------*/
// 与JS原生的alert、confirm、prompt交互，将弹出来的实际上是我们原生的窗口，而不是JS的。在得到数据后，由原生传回到JS：
#pragma mark - WKUIDelegate
// 可以指定配置对象、导航动作对象、window特性
//- (nullable WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures {
//
//}

// webview关闭时回调
- (void)webViewDidClose:(WKWebView *)webView {
     NSLog(@"LINE : LINE : %d -- %s",__LINE__, __FUNCTION__);
}

// 在JS端调用alert函数时，会触发此代理方法。
// JS端调用alert时所传的数据可以通过message拿到
// 在原生得到结果后，需要回调JS，是通过completionHandler回调
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    
    NSLog(@"LINE : LINE : %d -- %s",__LINE__, __FUNCTION__);
    
    // ios 原生的弹框
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"alert" message:@"JS调用alert" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"LINE : LINE : %d",__LINE__);
        completionHandler();
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
    NSLog(@"LINE : LINE : %d,message --- %@", __LINE__,message);
}

// JS端调用prompt函数时，会触发此方法
// 要求输入一段文本
// 在原生输入得到文本内容后，通过completionHandler回调给JS
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(nonnull NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(nonnull WKFrameInfo *)frame completionHandler:(nonnull void (^)(NSString * _Nullable))completionHandler {
    
     NSLog(@"LINE : LINE : %d -- %s,%@",__LINE__, __FUNCTION__,prompt);

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"textinput" message:@"JS调用输入框" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.textColor = [UIColor redColor];
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler([[alert.textFields lastObject] text]);
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];

}

// JS端调用confirm函数时，会触发此方法
// 通过message可以拿到JS端所传的数据
// 在iOS端显示原生alert得到YES/NO后
// 通过completionHandler回调给JS端
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(nonnull NSString *)message initiatedByFrame:(nonnull WKFrameInfo *)frame completionHandler:(nonnull void (^)(BOOL))completionHandler {
    
     NSLog(@"LINE : LINE : %d -- %s",__LINE__, __FUNCTION__);
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"confirm" message:@"JS调用confirm" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }]];
    [self presentViewController:alert animated:YES completion:NULL];

    NSLog(@"LINE : LINE : %d %@", __LINE__,message);
}


@end
