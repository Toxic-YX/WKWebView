//
//  AppDelegate.h
//  KKWebView
//
//  Created by 吴灶洲 on 2017/7/20.
//  Copyright © 2017年 吴灶洲. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

