//
//  ECGSendDoctorController.m
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import "ECGSendDoctorController.h"
#import "ECGWebProgressLayer.h"
#import "UIBarButtonItem+YX.h"
#import <WebKit/WebKit.h>

@interface ECGSendDoctorController ()<WKNavigationDelegate,WKUIDelegate>

@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) ECGWebProgressLayer *webProgressLayer;
@property (nonatomic, strong) UIView *noDataView;
@end

@implementation ECGSendDoctorController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self setSomeConfig];
    [self setNavConfig];
    [self setWebView];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.url]];
    [self.webView loadRequest:request];
    
    
   
}

- (void)setSomeConfig {
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    if (@available(iOS 11.0, *)) {
        self.webView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.title = self.webTitle;
}

- (void)setNavConfig {
    
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem setLeftItemWithImagName:@"arrow_left" target:self action:@selector(backButton:)];
}

- (void)backButton:(UIButton *)btn {
    
    [self.navigationController popViewControllerAnimated:YES];
    [self.webProgressLayer removeFromSuperlayer];
}

- (void)setWebView {
 
    [self.view addSubview:self.webView];
    [self.navigationController.navigationBar.layer addSublayer:self.webProgressLayer];
}

#pragma mark - UIWebViewDelegate
// 页面开始加载
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    
}

// 开始获取到网页内容时返回
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    
}

// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [self.webProgressLayer yx_finishedLoadWithError:nil];
}

// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    [self.webProgressLayer yx_finishedLoadWithError:error];
    // 请求失败加载
    NSLog(@"%@",error);
    
    if (_noDataView == nil) {
        _noDataView = [[UIView alloc] initWithFrame:self.view.bounds];
        [_noDataView setBackgroundColor:[UIColor orangeColor]];
        UITapGestureRecognizer *recongizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadAgain)];
        [_noDataView addGestureRecognizer:recongizer];
        [self.view addSubview:_noDataView];
    }else {
        _noDataView.hidden = NO;
    }
}


- (void)loadAgain {
    _noDataView.hidden = YES;
    if (!self.webView.isLoading) {
        [self.webProgressLayer yx_startLoad];
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.url]]];
    }
}

 // 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    
    [self.webProgressLayer yx_startLoad];
    
//    NSString *urlString = [[navigationAction.request URL] absoluteString];
//    urlString = [urlString stringByRemovingPercentEncoding];
//    NSArray *urlComps = [urlString componentsSeparatedByString:@"://"];
//    if ([urlComps count]) {
//        // 获取协议头
//        NSString *protocolHead = [urlComps objectAtIndex:0];
//        NSLog(@"protocolHead=%@",protocolHead);
//    }
    NSLog(@"%@",navigationAction.request.URL.absoluteString);
    //允许跳转
    decisionHandler(WKNavigationActionPolicyAllow);
}

// 在收到服务器的响应头，根据response相关信息，决定是否跳转。decisionHandler必须调用，来决定是否跳转，参数WKNavigationActionPolicyCancel取消跳转，WKNavigationActionPolicyAllow允许跳转
//- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
//
//}

// 接收到服务器跳转请求之后调用 (服务器端redirect)，不一定调用
//- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
//
//}

//#pragma mark - WKUIDelegate
///// 创建一个新的WebView
//- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures {
//
//    WKWebView *webV = [[WKWebView alloc] initWithFrame:self.view.bounds];
//    // 方式二
//    //    WKWebViewConfiguration * configuration = [[WKWebViewConfiguration alloc] init];
//    //    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
//    webV.navigationDelegate = self;
//    webV.UIDelegate = self;
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.baidu.com"]];
//    [webV loadRequest:request];
//    return webV;
//}
//
///// 输入框
//- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * __nullable result))completionHandler {
//
//}
//
///// 确认框
//- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler {
//
//}
//
///// 警告框
//- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
//
//}
//
///**
// web界面中有弹出警告框时调用
//
// @param webView 实现该代理的webview
// @param message 警告框中的内容
// @param completionHandler 警告框消失调用
// */
//- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(void (^)(void))completionHandler {
//
//}
//
//// WKScriptMessageHandler：必须实现的函数，是APP与js交互，提供从网页中收消息的回调方法，即js可以调用app的方法
//// 当然需要对webview做一些特殊处理，创建的时候做一些配置：- initWithFrame:configuration:,configuration为WKWebViewConfiguration类型，具体不再详述，代理方法如下
//// 这个协议中包含一个必须实现的方法，这个方法是提高App与web端交互的关键，它可以直接将接收到的JS脚本转化为OC或Swift对象
//// 从web界面中接收到一个脚本时调用
//- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
//
//}

- (void)dealloc {
    
    [self.webProgressLayer yx_closeTimer];
    [_webProgressLayer removeFromSuperlayer];
    _webProgressLayer = nil;
}


- (WKWebView *)webView {
    if (!_webView) {
        // 方式一
        _webView = [[WKWebView alloc] initWithFrame:self.view.bounds];
        // 方式二
        //    WKWebViewConfiguration * configuration = [[WKWebViewConfiguration alloc] init];
        //    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
        _webView.navigationDelegate = self;
//        _webView.UIDelegate = self;
        // 允许左右划手势导航，默认允许
        _webView.allowsBackForwardNavigationGestures = YES;
       
    }
    return _webView;
}

- (ECGWebProgressLayer *)webProgressLayer {
    
    if (!_webProgressLayer) {
        _webProgressLayer = [[ECGWebProgressLayer alloc] init];
        _webProgressLayer.frame = CGRectMake(0, self.navigationController.navigationBar.frame.size.height - 2, [UIScreen mainScreen].bounds.size.width, 2);
        _webProgressLayer.strokeColor = self.progressColor.CGColor;
    }
    return _webProgressLayer;
}

//- (UIView *)noDataView {
//    if (!_noDataView) {
//
//    }
//    return _noDataView;
//}

@end
