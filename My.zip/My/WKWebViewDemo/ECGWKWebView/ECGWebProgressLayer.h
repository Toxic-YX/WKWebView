//
//  ECGWebProgressLayer.h
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface ECGWebProgressLayer : CAShapeLayer

/**
 开始加载
 */
- (void)yx_startLoad;

/**
 完成加载

 @param error 错误提示
 */
- (void)yx_finishedLoadWithError:(NSError *)error;

/**
 关闭时间
 */
- (void)yx_closeTimer;

/**
 在KVO 计算  实际的读取进度时,调用改方法

 @param estimatedProgress 进度值
 */
- (void)yx_webViewPathChanged:(CGFloat)estimatedProgress;
@end
