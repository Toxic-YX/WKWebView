//
//  NSTimer+addition.h
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSTimer (addition)

/**
 暂停时间
 */
- (void)yx_pauseTime;

/**
 获取内容所在的当前时间
 */
- (void)yx_webPageTime;

/**
 当前时间

 @param time 秒后的时间
 */
- (void)yx_webPageTimeWithTimeInterval:(NSTimeInterval)time;

@end
