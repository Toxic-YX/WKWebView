//
//  UIBarButtonItem+YX.h
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (YX)

+ (instancetype)setLeftItemWithImagName:(NSString *)imgName target:(id)target action:(SEL)action;

@end
