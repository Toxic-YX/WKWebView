//
//  ECGWebProgressLayer.m
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import "ECGWebProgressLayer.h"
#import <UIKit/UIKit.h>
#import "NSTimer+addition.h"


@interface ECGWebProgressLayer()

@property (nonatomic, strong) CAShapeLayer *layer;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) CGFloat plusWidth;

@end

static NSTimeInterval const ProgressTimeInterval = 0.03;

@implementation ECGWebProgressLayer

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setBezierPath];
    }
    return self;
}

- (void)setBezierPath {
    // 绘制贝塞尔曲线
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 起点
    [path moveToPoint:CGPointMake(0, 3)];
    // 终点
    [path addLineToPoint:CGPointMake([UIScreen mainScreen].bounds.size.width, 3)];
    
    self.path = path.CGPath;
    self.strokeEnd = 0;
    _plusWidth = 0.005;
    self.lineWidth = 2;
//    self.strokeColor = [UIColor redColor].CGColor;
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:ProgressTimeInterval target:self selector:@selector(pathChanged:) userInfo:nil repeats:YES];
    [_timer yx_pauseTime];
}

- (void)pathChanged:(NSTimer *)timer {
    
    self.strokeEnd += _plusWidth;
    if (self.strokeEnd > 0.6) {
        _plusWidth = 0.002;
    }
    
    if (self.strokeEnd > 0.85) {
        _plusWidth = 0.0007;
    }
    
    if (self.strokeEnd > 0.93) {
        _plusWidth = 0;
    }
}

/**
 开始加载
 */
- (void)yx_startLoad {
    
    [_timer yx_webPageTimeWithTimeInterval:ProgressTimeInterval];
}

/**
 完成加载
 
 @param error 错误提示
 */
- (void)yx_finishedLoadWithError:(NSError *)error {
    
    CGFloat timer;
    if (error == nil) {
        [self yx_closeTimer];
        timer = 0.5;
        self.strokeEnd = 1.0;
    }else {
        timer = 1.0;
    }
    
    __weak typeof(self) weakSelf = self;
    // 延迟处理进度条消失问题
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(timer * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (timer == 1.0) {
            [weakSelf yx_closeTimer];
            self.strokeEnd = 1.0;
        }
        weakSelf.hidden = YES;
        [weakSelf removeFromSuperlayer];
    });
}

/**
 在KVO 计算  实际的读取进度时,调用改方法
 
 @param estimatedProgress 进度值
 */
- (void)yx_webViewPathChanged:(CGFloat)estimatedProgress {
    
    self.strokeEnd = estimatedProgress;
}

/**
 关闭时间
 */
- (void)yx_closeTimer {
    
    [_timer invalidate];
    _timer = nil;
}

- (void)dealloc {
    [self yx_closeTimer];
}

@end
