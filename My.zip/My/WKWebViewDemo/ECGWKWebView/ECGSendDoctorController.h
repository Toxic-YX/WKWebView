//
//  ECGSendDoctorController.h
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ECGSendDoctorController : UIViewController

// 链接
@property (nonatomic, copy) NSString *url;

// 标题
@property (nonatomic, copy) NSString *webTitle;

// 标题
@property (nonatomic, strong) UIColor *progressColor;

@end
