//
//  NSTimer+addition.m
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import "NSTimer+addition.h"

@implementation NSTimer (addition)

/**
 暂停时间
 */
- (void)yx_pauseTime {
    // 判断定时器是否有效
    if (!self.isValid) {
        return;
    }
    // 停止计时器
    [self setFireDate:[NSDate distantFuture]];
}

/**
 获取内容所在的当前时间
 */
- (void)yx_webPageTime {
    // 判断定时器是否有效
    if (!self.isValid) {
        return;
    }
    //返回当期时间
    [self setFireDate:[NSDate date]];
}

/**
 当前时间
 
 @param time 秒后的时间
 */
- (void)yx_webPageTimeWithTimeInterval:(NSTimeInterval)time {
    //判断定时器是否有效
    if (!self.isValid)  {
        return;
    }
    [self setFireDate:[NSDate dateWithTimeIntervalSinceNow:time]];
}

@end
