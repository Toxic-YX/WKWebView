//
//  ViewController.m
//  WKWebViewDemo
//
//  Created by YuXiang on 2017/11/7.
//  Copyright © 2017年 Rookie.YXiang. All rights reserved.
//

#import "ViewController.h"
#import "ECGSendDoctorController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)didClickBtn:(UIButton *)sender {
    
    ECGSendDoctorController *web = [[ECGSendDoctorController alloc] init];
    web.url = @"http://www.jianshu.com/u/9e396019b1ca";
    web.webTitle = @"web";
    web.progressColor = [UIColor grayColor];
    [self.navigationController pushViewController:web animated:YES];
    
}

@end
